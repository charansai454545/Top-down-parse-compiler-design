const EPS='ε', END='$';
export function parseGrammar(text){
 const g={};
 for(const [i,line0] of text.split(/\r?\n/).entries()){
  const line=line0.trim(); if(!line||line.startsWith('#'))continue;
  const match=line.match(/^(.+?)\s*(?:->|→|::=)\s*(.+)$/);
  if(!match) throw new Error(`Invalid production on line ${i+1}: use A -> α`);
  const lhs=match[1].trim(); if(!lhs)throw new Error(`Missing left-hand side on line ${i+1}`);
  const alts=match[2].split('|').map(s=>s.trim());
  if(!g[lhs])g[lhs]=[];
  for(const alt of alts){const rhs=(!alt||alt===EPS||alt.toLowerCase()==='epsilon'||alt==='e')?[]:alt.split(/\s+/);g[lhs].push(rhs);}
 }
 const nts=new Set(Object.keys(g));
 for(const [lhs,alts] of Object.entries(g)) for(const rhs of alts) for(const sym of rhs)
  if(/^[A-Z][A-Za-z0-9_']*$/.test(sym)&&!nts.has(sym)) throw new Error(`Undefined non-terminal "${sym}" used in ${lhs} -> ${rhs.join(' ')}`);
 return g;
}
const clone=g=>Object.fromEntries(Object.entries(g).map(([k,v])=>[k,v.map(r=>[...r])]));
export function eliminateLeftRecursion(input){
 const g=clone(input), notes=[], nts=Object.keys(g);
 for(let i=0;i<nts.length;i++){
  const Ai=nts[i];
  for(let j=0;j<i;j++){
   const Aj=nts[j], replaced=[];
   for(const rhs of g[Ai]){
    if(rhs[0]===Aj){for(const delta of g[Aj])replaced.push([...delta,...rhs.slice(1)]);}
    else replaced.push(rhs);
   }
   g[Ai]=replaced;
  }
  const recursive=g[Ai].filter(r=>r[0]===Ai), nonrecursive=g[Ai].filter(r=>r[0]!==Ai);
  if(recursive.length){
   if(!nonrecursive.length){notes.push(`${Ai}: all alternatives are left-recursive; no terminating base alternative exists. Review this rule manually.`);g[Ai]=recursive.map(r=>r.slice(1));continue;}
   let prime=Ai+"'";while(g[prime]||nts.includes(prime))prime+="'";
   nts.push(prime);g[prime]=[];
   g[Ai]=nonrecursive.map(r=>[...r,prime]);
   g[prime]=recursive.map(r=>[...r.slice(1),prime]);g[prime].push([]);
   notes.push(`Eliminated left recursion for ${Ai} using ${prime}.`);
  }
 }
 // Catch direct recursion still remaining, e.g. malformed/degenerate productions.
 const remaining=Object.entries(g).filter(([a,rs])=>rs.some(r=>r[0]===a)).map(([a])=>a);
 if(remaining.length)notes.push(`Left recursion may remain for: ${remaining.join(', ')}. Inspect the transformed grammar.`);
 if(!notes.length)notes.push('No left recursion found; grammar copied unchanged.');
 return {grammar:g,notes};
}
export function computeFirst(g){
 const nts=new Set(Object.keys(g)), first={};for(const n of nts)first[n]=new Set();
 const firstSeq=seq=>{const out=new Set();if(!seq.length){out.add(EPS);return out;}let all=true;
  for(const s of seq){if(!nts.has(s)){out.add(s);all=false;break;}for(const x of first[s])if(x!==EPS)out.add(x);if(!first[s].has(EPS)){all=false;break;}}
  if(all)out.add(EPS);return out;};
 let changed=true,guard=0;while(changed&&guard++<1000){changed=false;
  for(const [a,rules] of Object.entries(g))for(const rhs of rules){const fs=firstSeq(rhs);for(const x of fs)if(!first[a].has(x)){first[a].add(x);changed=true;}}
 }
 return Object.fromEntries(Object.entries(first).map(([k,v])=>[k,[...v].sort((a,b)=>a===EPS?1:b===EPS?-1:a.localeCompare(b))]));
}
export function computeFollow(g,first,start=Object.keys(g)[0]){
 const nts=new Set(Object.keys(g)), follow={};for(const n of nts)follow[n]=new Set();if(follow[start])follow[start].add(END);
 let changed=true,guard=0;while(changed&&guard++<1000){changed=false;
  for(const [a,rules] of Object.entries(g))for(const rhs of rules)for(let i=0;i<rhs.length;i++){
   const b=rhs[i];if(!nts.has(b))continue;const beta=rhs.slice(i+1);let fbeta=new Set();
   if(!beta.length)fbeta.add(EPS);else{let all=true;for(const s of beta){if(!nts.has(s)){fbeta.add(s);all=false;break;}for(const x of first[s]||[])if(x!==EPS)fbeta.add(x);if(!(first[s]||[]).includes(EPS)){all=false;break;}}if(all)fbeta.add(EPS);}
   for(const x of fbeta)if(x!==EPS&&!follow[b].has(x)){follow[b].add(x);changed=true;}
   if(fbeta.has(EPS))for(const x of follow[a])if(!follow[b].has(x)){follow[b].add(x);changed=true;}
  }
 }
 return Object.fromEntries(Object.entries(follow).map(([k,v])=>[k,[...v].sort()]));
}
export function buildParseTable(g,first,follow){
 const nts=new Set(Object.keys(g)), terminals=new Set(),cells={},placements=[],conflicts=[];
 for(const [a,rules] of Object.entries(g)){cells[a]={};for(const rhs of rules)for(const s of rhs)if(!nts.has(s)&&s!==EPS)terminals.add(s);}
 terminals.add(END);
 const seqFirst=seq=>{const out=new Set();if(!seq.length){out.add(EPS);return out;}let nullable=true;for(const s of seq){if(!nts.has(s)){out.add(s);nullable=false;break;}for(const x of first[s]||[])if(x!==EPS)out.add(x);if(!(first[s]||[]).includes(EPS)){nullable=false;break;}}if(nullable)out.add(EPS);return out;};
 for(const [a,rules] of Object.entries(g))for(const rhs of rules){const fs=seqFirst(rhs),p=`${a} → ${rhs.join(' ')||EPS}`,targets=new Set([...fs].filter(x=>x!==EPS));let reason='terminal(s) in FIRST of RHS';if(fs.has(EPS)){for(const x of follow[a]||[])targets.add(x);reason='ε in FIRST(RHS), so use FOLLOW('+a+')';}
  for(const t of targets){if(!terminals.has(t))terminals.add(t);cells[a][t]??=[];if(!cells[a][t].includes(p)){cells[a][t].push(p);placements.push({lhs:a,terminal:t,production:p,reason:fs.has(EPS)&&!(fs.has(t))?reason:`${t} ∈ FIRST(RHS)`});if(cells[a][t].length===2)conflicts.push({cell:`M[${a}, ${t}]`,productions:[...cells[a][t]]});}}
 }
 return {cells,terminals:[...terminals].sort((a,b)=>a===END?1:b===END?-1:a.localeCompare(b)),placements,conflicts};
}
export function ll1Trace(g,table,start,input){
 const nts=new Set(Object.keys(g)),tokens=input.trim()?input.trim().split(/\s+/):[],stream=[...tokens,END],stack=[END,start],steps=[];
 const add=(action,status='RUNNING')=>steps.push({stack:[...stack].reverse().join(' '),remaining:stream.slice(0,Math.max(0,stream.length-(stream.length-stream.length))).length?stream.join(' '):stream.join(' '),action,status});
 let ptr=0,guard=0;
 function record(action,status='RUNNING'){steps.push({stack:[...stack].join(' '),remaining:stream.slice(ptr).join(' '),action,status});}
 record('Initialize stack with start symbol '+start);
 while(stack.length&&guard++<500){
  const top=stack[stack.length-1],look=stream[ptr];
  if(top===END&&look===END){stack.pop();record('Both stack and input contain $ → ACCEPT','ACCEPT');return steps;}
  if(!nts.has(top)){if(top===look){stack.pop();ptr++;record(`Match terminal ${top}`);}else{record(`REJECT: expected ${top}, found ${look??'end of input'}`,'REJECT');return steps;}continue;}
  const prods=table.cells[top]?.[look]||[];
  if(prods.length!==1){record(prods.length===0?`REJECT: no table entry M[${top}, ${look}]`:`REJECT: conflict in M[${top}, ${look}]`,'REJECT');return steps;}
  const p=prods[0],rhsText=p.split('→')[1]?.trim()||EPS;stack.pop();const rhs=rhsText===EPS?[]:rhsText.split(/\s+/);for(let i=rhs.length-1;i>=0;i--)stack.push(rhs[i]);record(`Use ${p}`);
 }
 if(guard>=500)record('REJECT: safety limit reached (possible grammar cycle)','REJECT');
 else if(!steps.at(-1)?.status||steps.at(-1).status==='RUNNING')record('REJECT: input or stack not fully consumed','REJECT');
 return steps;
}
export function rdpTrace(g,start,input){
 const nts=new Set(Object.keys(g)),tokens=input.trim()?input.trim().split(/\s+/):[],steps=[];let budget=250;
 const log=(action,pos,stack,production='',status='RUNNING',reason='')=>steps.push({action,remaining:tokens.slice(pos).join(' ')||'$',stack:stack.join(' → '),production,status,reason});
 let finalStatus='REJECT';
 function parseNT(nt,pos,stack){
  if(--budget<0){log('Stop: recursion/step safety limit reached',pos,stack,'','REJECT','Possible left recursion. Transform the grammar first.');return null;}
  for(const rhs of (g[nt]||[])){
   const prod=`${nt} → ${rhs.join(' ')||EPS}`;log(`Enter ${nt}; try ${prod}`,pos,stack.concat(nt),prod);
   let p=pos,ok=true;
   for(const sym of rhs){
    if(nts.has(sym)){const res=parseNT(sym,p,stack.concat(nt));if(!res){ok=false;break;}p=res.pos;}
    else if(tokens[p]===sym){log(`Match terminal ${sym}`,p,stack.concat(nt),prod);p++;}
    else {log(`Production failed: ${prod}`,p,stack.concat(nt),prod,'RUNNING',`Expected ${sym}, found ${tokens[p]??'end of input'}`);ok=false;break;}
   }
   if(ok){log(`Return success from ${nt}`,p,stack.concat(nt),prod,'RUNNING');return {pos:p};}
   log(`Backtrack at ${nt}; try next alternative`,p,stack.concat(nt),prod,'RUNNING','Restore input position and try the next production.');
  }
  log(`All alternatives failed for ${nt}`,pos,stack.concat(nt),'','RUNNING');return null;
 }
 const res=parseNT(start,0,[]);
 if(res&&res.pos===tokens.length){finalStatus='ACCEPT';log('ACCEPT: input fully consumed',tokens.length,[],'',finalStatus);}
 else {finalStatus='REJECT';log('REJECT: no successful parse consumed the complete input',res?.pos||0,[],'',finalStatus,'The grammar may not match this input, or the RDP search limit was reached.');}
 if(!steps.length)log('No steps generated',0,[],'',finalStatus);
 return steps;
}


// Build a canonical LR(0) item automaton from a user-entered grammar.
export function buildLR0Automaton(grammarText) {
 const grammar = parseGrammar(grammarText);
 const names = Object.keys(grammar);
 if (!names.length) throw new Error('Enter at least one grammar production.');
 const start = names[0];
 let augmented = start + "'";
 while (grammar[augmented]) augmented += "'";
 const productions = [{lhs: augmented, rhs:[start]}];
 for (const [lhs, alternatives] of Object.entries(grammar))
  for (const rhs of alternatives) productions.push({lhs, rhs:[...rhs]});
 const byLhs = {};
 for (const p of productions) (byLhs[p.lhs] ||= []).push(p);
 const nonterminals = new Set(Object.keys(grammar).concat(augmented));
 const itemKey = items => items.map(i=>`${i.p}:${i.dot}`).sort((a,b)=>a.localeCompare(b)).join('|');
 const closure = seed => {
  const items = new Map(seed.map(i=>[`${i.p}:${i.dot}`,i]));
  let changed=true;
  while(changed){changed=false;
   for(const item of [...items.values()]){
    const sym=productions[item.p].rhs[item.dot];
    if(nonterminals.has(sym)) for(const p of (byLhs[sym]||[])){
     const idx=productions.indexOf(p), key=`${idx}:0`;
     if(!items.has(key)){items.set(key,{p:idx,dot:0});changed=true;}
    }
   }
  }
  return [...items.values()].sort((a,b)=>a.p-b.p||a.dot-b.dot);
 };
 const states=[], transitions=[], seen=new Map();
 const first=closure([{p:0,dot:0}]); states.push(first); seen.set(itemKey(first),0);
 for(let i=0;i<states.length;i++){
  const symbols=[...new Set(states[i].map(it=>productions[it.p].rhs[it.dot]).filter(Boolean))];
  for(const sym of symbols){
   const moved=states[i].filter(it=>productions[it.p].rhs[it.dot]===sym).map(it=>({p:it.p,dot:it.dot+1}));
   const next=closure(moved), key=itemKey(next);
   let target=seen.get(key);
   if(target===undefined){target=states.length;seen.set(key,target);states.push(next);}
   transitions.push({from:i,to:target,symbol:sym});
  }
 }
 const cols=3, rows=Math.ceil(states.length/cols);
 return {
  states: states.map((items,i)=>({
   id:`I${i}`, title:i===0?'START':(items.some(it=>it.p===0&&it.dot===1)?'ACCEPT':'STATE'),
   lines:items.map(it=>{const p=productions[it.p],rhs=[...p.rhs];rhs.splice(it.dot,0,'·');return `${p.lhs} → ${rhs.join(' ')||'·'}`;}),
   desc:items.map(it=>{const p=productions[it.p],rhs=[...p.rhs];rhs.splice(it.dot,0,'·');return `${p.lhs} → ${rhs.join(' ')||'·'}`;}).join('\n'),
   x:i%cols,y:Math.floor(i/cols)
  })),
  transitions, augmentedStart:augmented, rows
 };
}
