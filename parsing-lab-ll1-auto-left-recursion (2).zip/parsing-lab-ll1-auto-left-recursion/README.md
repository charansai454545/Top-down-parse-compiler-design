# Parsing Lab — React Top-Down Parser Visualizer

## Run from the beginning (Windows)

1. Install **Node.js LTS** from https://nodejs.org/ and restart VS Code/Command Prompt.
2. Extract this ZIP to a simple folder, for example `C:\Projects\top-down-parser-react`.
3. Open that folder in VS Code (`File → Open Folder`). The folder you open must contain `package.json`.
4. Open the VS Code terminal (`Terminal → New Terminal`).
5. Run these commands one at a time:

```bash
npm install
npm run dev
```

6. Open the exact local URL Vite prints, normally `http://localhost:5173/`.
7. Use **Parser Lab** for RDP, FIRST/FOLLOW, LL(1) table, and string parsing. Use **Flowcharts** for the interactive state diagram.

### If the page is blank

- Check the terminal running Vite for red error messages.
- In Chrome, press `F12` → **Console** and inspect the first red error.
- Stop the server with `Ctrl+C`, then run `npm install` and `npm run dev` again.
- Ensure you opened the project root containing `package.json`, not just the `src` folder.
- Use the exact URL printed by Vite. This project has `/`, `/top-down`, and `/flowcharts` routes.

If Vite says `'vite' is not recognized`, run `npm install` from the project root first. Do not install packages globally.

## Grammar input format

Use one production per line and separate symbols with spaces:

```text
E -> E + T | T
T -> T * F | F
F -> ( E ) | id
```

Use `ε` for the empty production. The first left-hand-side symbol becomes the start symbol. Click **Load grammar** before running a parser. For a left-recursive grammar, click **Eliminate left recursion**, then inspect the transformed grammar.

## What is included

- React + Vite single-page app
- Recursive descent trace with alternative attempts and backtracking
- FIRST and FOLLOW sets
- LL(1) predictive parsing table and conflict warnings
- Step-by-step LL(1) input parsing
- Ordered-substitution left-recursion elimination
- Reference-inspired flowchart state canvas with clickable state inspector and step controls

## Project structure

- `src/main.jsx` — React entry point and router
- `src/App.jsx` — pages, UI, state controls, and visualizer
- `src/algorithms.js` — grammar parsing, left recursion, FIRST/FOLLOW, table generation, parsing traces
- `src/styles.css` — layout and modern dark theme
- `index.html` — browser entry page
- `package.json` — scripts and dependencies

## Important academic note

The Flowcharts page is an illustrative LR item-state diagram matching the style of the reference screenshot; it is not a generated state graph for every arbitrary grammar. The actual RDP and LL(1) analysis runs in Parser Lab. RDP is a teaching trace; eliminate left recursion before testing grammars with left-recursive productions. Review transformed grammars for unusual unproductive or cyclic rules.
